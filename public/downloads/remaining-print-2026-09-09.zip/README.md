# 小鴨剩餘列印清單（已套用一體版與照片庫存）

2026-09-09 更新：共 **31 份 STL，30 件 PLA、1 件 TPU**。每個檔案印一次即可，不要額外乘以數量。

## 這次更正

- 左大腿與左小腿各用一件「v2 中間固定孔補滿的一體版」，兩份檔案分別標示 01_of_02／02_of_02。它们是相同幾何，沒有鏡射。
- 已移出原本兩種薄板各2片、spacer 2件，共6件；改成2件一體版。不需另印 spacer 或薄板。
- 照片 IMG_4562.HEIC 外形對照：roll_motor_bottom 1件、roll_motor_top 2件。左腿各用1件，另1件top留作備品；兩種髖座都已從列印包移出。
- 舊檔已移到專案的 docs/build-guide/print-package-history/2026-09-09-before-unibody，桌面這包僅保留本次要印的31件。

## 列印順序與材料

1. 01_左腿：7件（PLA 6、TPU 1）
2. 02_腿部外側護蓋：2件 PLA（left_cache／right_cache）
3. 02_身體外殼：6件 PLA
4. 03_頸部：5件 PLA
5. 04_頭部：11件 PLA

PLA 15% 填充，TPU 40% 填充（原專案指南）；一體版仍需在切片器確認支撐、擺放與貼床。全部是毫米單位STL，尚未切片。

## 一體件適用與組裝

CAD核對四段腿部使用相同來源薄板與spacer，零件相對變換差小於1e-8，可使用同一一體模型而不鏡射；附相容性核對JSON。這確認幾何配置相同，不等於左腿實物裝入驗證已完成。先印一件試裝舵機、舵盤與走線，再印第二件；裝入前先接好將被遮住的線路。

已按右腿及 trunk_bottom 完成扣除；若右腳TPU底片實際未印，仍需另補1件。其餘身體與頭部按尚未印計算。

## 逐件勾選（每檔1件）

- [ ] `01_左腿/PLA_15%/foot_bottom_pla__01_of_01.stl`
- [ ] `01_左腿/PLA_15%/foot_side__01_of_01.stl`
- [ ] `01_左腿/PLA_15%/foot_top__01_of_01.stl`
- [ ] `01_左腿/PLA_15%/left_roll_to_pitch__01_of_01.stl`
- [ ] `01_左腿/PLA_15%/leg-unibody-v2-filled__01_of_02__左大腿.stl`
- [ ] `01_左腿/PLA_15%/leg-unibody-v2-filled__02_of_02__左小腿.stl`
- [ ] `01_左腿/TPU_40%/foot_bottom_tpu__01_of_01.stl`
- [ ] `02_身體外殼/PLA_15%/battery_pack_lid__01_of_01.stl`
- [ ] `02_身體外殼/PLA_15%/body_back__01_of_01.stl`
- [ ] `02_身體外殼/PLA_15%/body_front__01_of_01.stl`
- [ ] `02_身體外殼/PLA_15%/body_middle_bottom__01_of_01.stl`
- [ ] `02_身體外殼/PLA_15%/body_middle_top__01_of_01.stl`
- [ ] `02_腿部外側護蓋/PLA_15%/left_cache__01_of_01.stl`（左大腿外側護蓋）
- [ ] `02_腿部外側護蓋/PLA_15%/right_cache__01_of_01.stl`（右大腿外側護蓋）
- [ ] `02_身體外殼/PLA_15%/trunk_top__01_of_01.stl`
- [ ] `03_頸部/PLA_15%/head_pitch_to_yaw__01_of_01.stl`
- [ ] `03_頸部/PLA_15%/head_roll_mount__01_of_01.stl`
- [ ] `03_頸部/PLA_15%/head_yaw_to_roll__01_of_01.stl`
- [ ] `03_頸部/PLA_15%/neck_left_sheet__01_of_01.stl`
- [ ] `03_頸部/PLA_15%/neck_right_sheet__01_of_01.stl`
- [ ] `04_頭部/PLA_15%/bulb__01_of_01.stl`
- [ ] `04_頭部/PLA_15%/flash_light_module__01_of_01.stl`
- [ ] `04_頭部/PLA_15%/flash_reflector_interface__01_of_01.stl`
- [ ] `04_頭部/PLA_15%/head__01_of_01.stl`
- [ ] `04_頭部/PLA_15%/head_bot_sheet__01_of_01.stl`
- [ ] `04_頭部/PLA_15%/left_antenna_holder__01_of_01.stl`
- [ ] `04_頭部/PLA_15%/left_eye__01_of_01.stl`
- [ ] `04_頭部/PLA_15%/right_antenna_holder__01_of_01.stl`
- [ ] `04_頭部/PLA_15%/right_eye__01_of_01.stl`
- [ ] `04_頭部/PLA_15%/speaker_interface__01_of_01.stl`
- [ ] `04_頭部/PLA_15%/speaker_stand__01_of_01.stl`
