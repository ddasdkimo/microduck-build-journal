"""Build CAD-derived assembly data. Does not access or move hardware.

Source meshes are metres in robot.urdf (NOT the print STLs in millimetres).
URDF visual origins and joint origins are both applied, all joint angles zero.
Exploded offsets are presentation only; assembled positions are unmodified CAD.
"""
from pathlib import Path
import base64, hashlib, json, xml.etree.ElementTree as ET
import numpy as np
import trimesh
from scipy.spatial.transform import Rotation

ROOT = Path(__file__).resolve().parents[2]
SOURCE = ROOT / 'Open_Duck_Mini/mini_bdx/robots/open_duck_mini_v2'
OUT = ROOT / 'docs/build-guide'
IDS = {'right_hip_yaw':10,'right_hip_roll':11,'right_hip_pitch':12,'right_knee':13,'right_ankle':14,
       'left_hip_yaw':20,'left_hip_roll':21,'left_hip_pitch':22,'left_knee':23,'left_ankle':24,
       'neck_pitch':30,'head_pitch':31,'head_yaw':32,'head_roll':33}
LABELS={10:'右髖 yaw',11:'右髖 roll',12:'右髖 pitch',13:'右膝',14:'右踝',20:'左髖 yaw',21:'左髖 roll',22:'左髖 pitch',23:'左膝',24:'左踝',30:'頸 pitch',31:'頭 pitch',32:'頭 yaw',33:'頭 roll'}

def tf(origin):
    a=np.eye(4)
    if origin is not None:
        a[:3,:3]=Rotation.from_euler('xyz',list(map(float,origin.get('rpy','0 0 0').split()))).as_matrix()
        a[:3,3]=list(map(float,origin.get('xyz','0 0 0').split()))
    return a

def build():
    root=ET.parse(SOURCE/'robot.urdf').getroot()
    worlds={'trunk_assembly':np.eye(4)}; joints={}
    pending=list(root.findall('joint'))
    while pending:
        progress=False
        for j in pending[:]:
            parent=j.find('parent').get('link'); child=j.find('child').get('link')
            if parent not in worlds: continue
            worlds[child]=worlds[parent]@tf(j.find('origin'))
            joints[j.get('name')]=worlds[child][:3,3]*1000
            pending.remove(j);progress=True
        if not progress: raise RuntimeError('Unresolved URDF graph')
    meshes={}; visuals=[]; motors={}
    for link in root.findall('link'):
        lname=link.get('name');motor=None
        for vi,v in enumerate(link.findall('visual')):
            f=v.find('geometry/mesh').get('filename').split('/')[-1]
            if f not in meshes:
                meshes[f]=trimesh.load(SOURCE/f,force='mesh',process=False)
            mesh=meshes[f]; matrix=worlds[lname]@tf(v.find('origin'))
            verts=trimesh.transform_points(mesh.vertices,matrix)*1000
            center=(verts.min(axis=0)+verts.max(axis=0))/2
            if f.startswith('wj-wk00-0123'):
                motor=f'{lname}-motor-{vi}'; motors[motor]=[]
            is_motor=f.startswith('wj-') or f in ['drive_palonier.stl','passive_palonier.stl']
            item={'key':f'{lname}:{vi}','link':lname,'mesh':f,'matrix':matrix,'vertices':verts,
                  'center':center,'motor':motor if is_motor else None}
            visuals.append(item)
            if is_motor: motors[motor].append(item)
    # Identify each servo by the joint closest to its drive horn, using CAD geometry.
    for key,items in motors.items():
        horn=next(i for i in items if i['mesh']=='drive_palonier.stl')
        joint=min(IDS,key=lambda j:np.linalg.norm(joints[j]-horn['center']))
        distance=np.linalg.norm(joints[joint]-horn['center'])
        if distance>20: raise RuntimeError(f'Servo mapping too far: {key} {joint} {distance}')
        for item in items: item['id']=IDS[joint]
        print('Servo',IDS[joint],key,'horn distance mm',round(distance,2))
    assert sorted({i['id'] for i in visuals if 'id' in i})==sorted(IDS.values())

    geom={}
    for name,m in meshes.items():
        geom[name]={'p':base64.b64encode(np.asarray(m.vertices,dtype='<f4').tobytes()).decode(),
                    'i':base64.b64encode(np.asarray(m.faces,dtype='<u4').tobytes()).decode()}
    def select(mesh=None,link=None,id=None):
        return [v for v in visuals if (mesh is None or v['mesh']==mesh) and (link is None or v['link']==link) and (id is None or v.get('id')==id)]
    groups=[]
    def add(key,name,items,color,offset,detail):
        assert items,key
        allv=np.concatenate([i['vertices'] for i in items])
        groups.append({'key':key,'name':name,'items':[i['key'] for i in items],'color':color,'offset':offset,
                       'center':((allv.min(0)+allv.max(0))/2).round(4).tolist(),'detail':detail})
        return key
    gold='#d19c39'; dark='#3b4b5c'; steel='#81969a'; teal='#2a9290'
    add('id10','ID 10 · 右髖 yaw',select(id=10),dark,[0,0,100],'已驗收、設 ID、裝舵盤。向下的主動舵盤接 roll_motor_top；上端圓盤是背面支承盤。')
    add('rolltop','roll_motor_top',select('roll_motor_top.stl','hip_roll_assembly_2'),gold,[0,0,60],'四個固定孔對準 ID 10 下方主動舵盤；依官方指示由底部往上鎖。此件不壓熱熔嵌件。')
    add('id11','ID 11 · 右髖 roll',select(id=11),dark,[0,0,10],'側向輸出接 right_roll_to_pitch。舵機外殼由 roll_motor_top 與 roll_motor_bottom 共同支承。')
    add('rollbottom','roll_motor_bottom',select('roll_motor_bottom.stl','hip_roll_assembly_2'),gold,[0,0,-35],'底部約 Ø20 凸軸進入 6804ZZ 內圈；不是把軸承外圈壓進這個零件。')
    bearing=min(select('roll_bearing.stl','trunk_assembly'),key=lambda v:v['center'][1])
    add('bearing','6804ZZ · 右髖軸承',[bearing],steel,[0,0,-80],'內圈接 roll_motor_bottom 凸軸；外圈固定在 trunk_bottom 的座孔。左右髖各一顆。')
    add('trunkbottom','trunk_bottom',select('trunk_bottom.stl','trunk_assembly'),teal,[0,0,-185],'軀幹底座，承接兩側髖軸承。已提前排入批次 1；列印完成與外圈試配尚待現場回報。')
    hip=[g['key'] for g in groups]
    add('rbridge','right_roll_to_pitch',select('right_roll_to_pitch.stl'),gold,[35,-75,-20],'右側專用連接件。連接 ID 11 輸出與 ID 12 機身；勿與 left_roll_to_pitch 混用。')
    add('id12','ID 12 · 右髖 pitch',select(id=12),dark,[35,-95,-20],'大腿上端。裝配方向採官方 CAD 零位，實機仍需後續校正。')
    thigh=[v for v in visuals if v['link']=='knee_and_ankle_assembly_3' and not v['motor'] and 'cache' not in v['mesh']]
    add('rthigh','右大腿 · 薄板 ×2＋spacer',thigh,gold,[0,-100,-65],'左右薄板各一片、leg_spacer 一件。每件 spacer 用四顆嵌件；先辨識孔位，再裝兩端舵機。')
    add('id13','ID 13 · 右膝',select(id=13),dark,[0,-135,-95],'上下連接大腿與小腿。先確認相鄰結構與線路不干涉，不以模擬角度當作真實機械止點。')
    shin=[v for v in visuals if v['link']=='knee_and_ankle_assembly_4' and not v['motor']]
    add('rshin','右小腿 · 薄板 ×2＋spacer',shin,gold,[0,-100,-125],'裝薄板前先插踝舵機線，讓線穿過指定開孔，避免封住後難以插接。')
    add('id14','ID 14 · 右踝',select(id=14),dark,[0,-135,-160],'安裝在腳部，驅動板所在的一面朝 foot_top。以官方組裝圖辨認，不能只憑線朝哪裡判斷。')
    for key,mesh,name,off,detail in [
      ('foottop','foot_top.stl','foot_top · 上蓋',[0,-100,-170],'三顆嵌件；孔深先量再選嵌件長度。'),
      ('footside','foot_side.stl','foot_side · 側板',[65,-120,-190],'與踝舵機、上蓋合裝；鎖塑膠的螺絲不使用螺紋膠。'),
      ('footpla','foot_bottom_pla.stl','foot_bottom_pla · 硬底',[0,-100,-220],'兩顆嵌件；用兩顆 M3×6 接 TPU 腳底。'),
      ('foottpu','foot_bottom_tpu.stl','foot_bottom_tpu · 軟底',[0,-100,-255],'TPU 40% 填充，與 PLA 硬底配合。腳底開關另依官方圖壓入。')]:
        add(key,name,select(mesh,'foot_assembly_2'),teal if key=='foottpu' else gold,off,detail)
    right=[g['key'] for g in groups]
    used={k for g in groups for k in g['items']}
    leftlinks=['hip_roll_assembly','left_roll_to_pitch_assembly','knee_and_ankle_assembly','knee_and_ankle_assembly_2','foot_assembly']
    add('leftleg','左腿總成 · ID 20–24',[v for v in visuals if v['link'] in leftlinks or v.get('id')==20],gold,[0,140,-35],'左腿結構對應右腿；使用 left_roll_to_pitch。ID 20–24，實體尚未回報組裝完成。')
    necklinks=['neck_pitch_assembly','head_pitch_to_yaw','neck_yaw_assembly']
    add('neck','頸部與頭部關節',[v for v in visuals if v['link'] in necklinks or v.get('id')==30],dark,[0,0,90],'頸／頭 ID 30–33 依官方設定表。圖中是 CAD 設計姿態，不是實機站姿校正結果。')
    add('head','頭部總成',[v for v in visuals if v['link'] in ['head_assembly','left_antenna_holder','right_antenna_holder']],teal,[0,0,180],'含頭殼、支承軸承與 CAD 電子件。CAD 板件僅作位置參考，不代表此次採購板型或接線。')
    add('torso','軀幹與 CAD 電子件',[v for v in visuals if v['link']=='trunk_assembly' and v['key'] not in used and v.get('id') not in [20,30]],steel,[90,0,15],'外殼、電池與電子件依上游 CAD 配置；此次 BMS／充電器不同，接線以實際板子與量測為準。')
    # Full assembly groups right leg rigidly: high-level explosion rather than scattered every part.
    full=[{'key':'full-right','name':'右腿總成 · ID 10–14','items':[k for g in groups if g['key'] in right and g['key']!='trunkbottom' for k in g['items']],
           'color':gold,'offset':[0,-140,-35],'center':[0,-80,-100],'detail':'右腿五顆 ID 已配置。此模式整條腿一起移開；切換右腿模式可拆看內部零件。'}]
    full.extend([g for g in groups if g['key'] in ['trunkbottom','leftleg','neck','head','torso']])
    full[0]['items'] += [v['key'] for v in visuals if v['link']=='knee_and_ankle_assembly_3' and 'cache' in v['mesh']]
    offsets={'full-right':[0,-240,-60],'trunkbottom':[0,0,0],'leftleg':[0,280,-60],'neck':[0,0,100],'head':[0,0,220],'torso':[-230,0,90]}
    full=[{**g,'offset':offsets[g['key']]} for g in full]
    all_keys=[k for g in full for k in g['items']]
    assert len(all_keys)==len(set(all_keys))==len(visuals), 'Full scene must include every visual once'
    def serial(v):
        mat=v['matrix'].copy();mat[:3,:]*=1000
        return {'key':v['key'],'mesh':v['mesh'],'matrix':mat.T.reshape(-1).round(7).tolist(),'id':v.get('id')}
    data={'version':'2026-09-07','source':'Open_Duck_Mini/mini_bdx/robots/open_duck_mini_v2/robot.urdf',
          'sourceSha256':hashlib.sha256((SOURCE/'robot.urdf').read_bytes()).hexdigest(),
          'geometries':geom,'visuals':[serial(v) for v in visuals],
          'scenes':{'hip':{'title':'右髖座','groups':groups[:6]},'right':{'title':'右腿','groups':[g for g in groups if g['key'] in right]},'full':{'title':'全機總成','groups':full}}}
    (OUT/'assembly-data.json').write_text(json.dumps(data,separators=(',',':'),ensure_ascii=False))
    print('Wrote assembly-data.json',len(geom),'meshes',len(visuals),'visual instances')
    return data,visuals,meshes

if __name__=='__main__': build()
