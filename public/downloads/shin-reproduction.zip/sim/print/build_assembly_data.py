"""Build CAD-derived assembly data. Does not access or move hardware.

Source meshes are metres in robot.urdf (NOT the print STLs in millimetres).
URDF visual origins and joint origins are both applied, all joint angles zero.
Exploded offsets are presentation only; assembled positions are unmodified CAD.
"""
from pathlib import Path
import base64, hashlib, json, xml.etree.ElementTree as ET
import numpy as np
import trimesh
from scipy.spatial.transform import Rotation

ROOT = Path(__file__).resolve().parents[2]
SOURCE = ROOT / 'Open_Duck_Mini/mini_bdx/robots/open_duck_mini_v2'
PRINT = ROOT / 'Open_Duck_Mini/print'
OUT = ROOT / 'docs/build-guide'
IDS = {'right_hip_yaw':10,'right_hip_roll':11,'right_hip_pitch':12,'right_knee':13,'right_ankle':14,
       'left_hip_yaw':20,'left_hip_roll':21,'left_hip_pitch':22,'left_knee':23,'left_ankle':24,
       'neck_pitch':30,'head_pitch':31,'head_yaw':32,'head_roll':33}
LABELS={10:'右髖 yaw',11:'右髖 roll',12:'右髖 pitch',13:'右膝',14:'右踝',20:'左髖 yaw',21:'左髖 roll',22:'左髖 pitch',23:'左膝',24:'左踝',30:'頸 pitch',31:'頭 pitch',32:'頭 yaw',33:'頭 roll'}

def tf(origin):
    a=np.eye(4)
    if origin is not None:
        a[:3,:3]=Rotation.from_euler('xyz',list(map(float,origin.get('rpy','0 0 0').split()))).as_matrix()
        a[:3,3]=list(map(float,origin.get('xyz','0 0 0').split()))
    return a

def build():
    root=ET.parse(SOURCE/'robot.urdf').getroot()
    worlds={'trunk_assembly':np.eye(4)}; joints={}
    pending=list(root.findall('joint'))
    while pending:
        progress=False
        for j in pending[:]:
            parent=j.find('parent').get('link'); child=j.find('child').get('link')
            if parent not in worlds: continue
            worlds[child]=worlds[parent]@tf(j.find('origin'))
            joints[j.get('name')]=worlds[child][:3,3]*1000
            pending.remove(j);progress=True
        if not progress: raise RuntimeError('Unresolved URDF graph')
    meshes={}; visuals=[]; motors={}
    for link in root.findall('link'):
        lname=link.get('name');motor=None
        for vi,v in enumerate(link.findall('visual')):
            f=v.find('geometry/mesh').get('filename').split('/')[-1]
            if f not in meshes:
                meshes[f]=trimesh.load(SOURCE/f,force='mesh',process=False)
            mesh=meshes[f]; matrix=worlds[lname]@tf(v.find('origin'))
            verts=trimesh.transform_points(mesh.vertices,matrix)*1000
            center=(verts.min(axis=0)+verts.max(axis=0))/2
            if f.startswith('wj-wk00-0123'):
                motor=f'{lname}-motor-{vi}'; motors[motor]=[]
            is_motor=f.startswith('wj-') or f in ['drive_palonier.stl','passive_palonier.stl']
            item={'key':f'{lname}:{vi}','link':lname,'mesh':f,'matrix':matrix,'vertices':verts,
                  'center':center,'motor':motor if is_motor else None}
            visuals.append(item)
            if is_motor: motors[motor].append(item)
    # Identify each servo by the joint closest to its drive horn, using CAD geometry.
    for key,items in motors.items():
        horn=next(i for i in items if i['mesh']=='drive_palonier.stl')
        joint=min(IDS,key=lambda j:np.linalg.norm(joints[j]-horn['center']))
        distance=np.linalg.norm(joints[joint]-horn['center'])
        if distance>20: raise RuntimeError(f'Servo mapping too far: {key} {joint} {distance}')
        for item in items: item['id']=IDS[joint]
        print('Servo',IDS[joint],key,'horn distance mm',round(distance,2))
    assert sorted({i['id'] for i in visuals if 'id' in i})==sorted(IDS.values())

    # These print STLs are omitted from robot.urdf but share head.stl's CAD frame.
    head_ref=next(v for v in visuals if v['link']=='head_assembly' and v['mesh']=='head.stl')
    for name in ['left_eye.stl','right_eye.stl','bulb.stl','flash_light_module.stl',
                 'flash_reflector_interface.stl','speaker_interface.stl','speaker_stand.stl']:
        # Merge STL's repeated triangle vertices to keep the embedded WebGL guide small.
        raw=trimesh.load(PRINT/name,force='mesh',process=True); raw.apply_scale(.001)
        meshes[name]=raw; matrix=head_ref['matrix'].copy()
        verts=trimesh.transform_points(raw.vertices,matrix)*1000
        visuals.append({'key':f'head_accessories:{name}','link':'head_accessories','mesh':name,
                        'matrix':matrix,'vertices':verts,'center':(verts.min(0)+verts.max(0))/2,'motor':None})

    geom={}
    for name,m in meshes.items():
        geom[name]={'p':base64.b64encode(np.asarray(m.vertices,dtype='<f4').tobytes()).decode(),
                    'i':base64.b64encode(np.asarray(m.faces,dtype='<u4').tobytes()).decode()}
    def select(mesh=None,link=None,id=None):
        return [v for v in visuals if (mesh is None or v['mesh']==mesh) and (link is None or v['link']==link) and (id is None or v.get('id')==id)]
    groups=[]
    def make(key,name,items,color,offset,detail):
        assert items,key
        allv=np.concatenate([i['vertices'] for i in items])
        return {'key':key,'name':name,'items':[i['key'] for i in items],'color':color,'offset':offset,
                'center':((allv.min(0)+allv.max(0))/2).round(4).tolist(),'detail':detail}
    def add(key,name,items,color,offset,detail):
        groups.append(make(key,name,items,color,offset,detail))
        return key
    gold='#d19c39'; dark='#3b4b5c'; steel='#81969a'; teal='#2a9290'
    add('id10','ID 10 · 右髖 yaw',select(id=10),dark,[0,0,100],'已驗收、設 ID、裝舵盤。向下的主動舵盤接 roll_motor_top；上端圓盤是背面支承盤。')
    add('rolltop','roll_motor_top',select('roll_motor_top.stl','hip_roll_assembly_2'),gold,[0,0,60],'四個固定孔對準 ID 10 下方主動舵盤；依官方指示由底部往上鎖。此件不壓熱熔嵌件。')
    add('id11','ID 11 · 右髖 roll',select(id=11),dark,[0,0,10],'側向輸出接 right_roll_to_pitch。舵機外殼由 roll_motor_top 與 roll_motor_bottom 共同支承。')
    add('rollbottom','roll_motor_bottom',select('roll_motor_bottom.stl','hip_roll_assembly_2'),gold,[0,0,-35],'底部約 Ø20 凸軸進入 6804ZZ 內圈；不是把軸承外圈壓進這個零件。')
    bearing=min(select('roll_bearing.stl','trunk_assembly'),key=lambda v:v['center'][1])
    add('bearing','6804ZZ · 右髖軸承',[bearing],steel,[0,0,-80],'內圈接 roll_motor_bottom 凸軸；外圈固定在 trunk_bottom 的座孔。左右髖各一顆。')
    add('trunkbottom','trunk_bottom',select('trunk_bottom.stl','trunk_assembly'),teal,[0,0,-185],'軀幹底座，承接兩側髖軸承。已提前排入批次 1；列印完成與外圈試配尚待現場回報。')
    hip=[g['key'] for g in groups]
    add('rbridge','right_roll_to_pitch',select('right_roll_to_pitch.stl'),gold,[35,-75,-20],'右側專用連接件。連接 ID 11 輸出與 ID 12 機身；勿與 left_roll_to_pitch 混用。')
    add('id12','ID 12 · 右髖 pitch',select(id=12),dark,[35,-95,-20],'大腿上端。裝配方向採官方 CAD 零位，實機仍需後續校正。')
    thigh=[v for v in visuals if v['link']=='knee_and_ankle_assembly_3' and not v['motor'] and 'cache' not in v['mesh']]
    add('rthigh','右大腿 · 薄板 ×2＋spacer',thigh,gold,[0,-100,-65],'左右薄板各一片、leg_spacer 一件。每件 spacer 用四顆嵌件；先辨識孔位，再裝兩端舵機。')
    add('rcache','right_cache · 右腿外側護蓋',select('right_cache.stl','knee_and_ankle_assembly_3'),teal,[90,-120,-65],'這是右大腿外側護蓋，不是軀幹外殼。大腿與走線確認完成後再封上，避免後續為接線而拆卸。')
    add('id13','ID 13 · 右膝',select(id=13),dark,[0,-135,-95],'上下連接大腿與小腿。先確認相鄰結構與線路不干涉，不以模擬角度當作真實機械止點。')
    shin=[v for v in visuals if v['link']=='knee_and_ankle_assembly_4' and not v['motor']]
    add('rshin','右小腿 · 薄板 ×2＋spacer',shin,gold,[0,-100,-125],'裝薄板前先插踝舵機線，讓線穿過指定開孔，避免封住後難以插接。')
    add('id14','ID 14 · 右踝',select(id=14),dark,[0,-135,-160],'安裝在腳部，驅動板所在的一面朝 foot_top。以官方組裝圖辨認，不能只憑線朝哪裡判斷。')
    for key,mesh,name,off,detail in [
      ('foottop','foot_top.stl','foot_top · 上蓋',[0,-100,-170],'三顆嵌件；孔深先量再選嵌件長度。'),
      ('footside','foot_side.stl','foot_side · 側板',[65,-120,-190],'與踝舵機、上蓋合裝；鎖塑膠的螺絲不使用螺紋膠。'),
      ('footpla','foot_bottom_pla.stl','foot_bottom_pla · 硬底',[0,-100,-220],'兩顆嵌件；用兩顆 M3×6 接 TPU 腳底。'),
      ('foottpu','foot_bottom_tpu.stl','foot_bottom_tpu · 軟底',[0,-100,-255],'TPU 40% 填充，與 PLA 硬底配合。腳底開關另依官方圖壓入。')]:
        add(key,name,select(mesh,'foot_assembly_2'),teal if key=='foottpu' else gold,off,detail)
    right=[g['key'] for g in groups]
    used={k for g in groups for k in g['items']}
    leftlinks=['hip_roll_assembly','left_roll_to_pitch_assembly','knee_and_ankle_assembly','knee_and_ankle_assembly_2','foot_assembly']
    add('leftleg','左腿總成 · ID 20–24',[v for v in visuals if v['link'] in leftlinks or v.get('id')==20],gold,[0,140,-35],'左腿結構對應右腿；使用 left_roll_to_pitch。ID 20–24，實體尚未回報組裝完成。')
    necklinks=['neck_pitch_assembly','head_pitch_to_yaw','neck_yaw_assembly']
    add('neck','頸部與頭部關節',[v for v in visuals if v['link'] in necklinks or v.get('id')==30],dark,[0,0,90],'頸／頭 ID 30–33 依官方設定表。圖中是 CAD 設計姿態，不是實機站姿校正結果。')
    head_links=['head_assembly','left_antenna_holder','right_antenna_holder','head_accessories']
    add('head','頭部總成',[v for v in visuals if v['link'] in head_links],teal,[0,0,180],'含頭殼、支承軸承、表情模組與 CAD 電子件。表情零件使用官方列印 STL 的共同 CAD 座標。')
    add('torso','軀幹與 CAD 電子件',[v for v in visuals if v['link']=='trunk_assembly' and v['key'] not in used and v.get('id') not in [20,30]],steel,[90,0,15],'外殼、電池與電子件依上游 CAD 配置；此次 BMS／充電器不同，接線以實際板子與量測為準。')
    # Full assembly groups right leg rigidly: high-level explosion rather than scattered every part.
    full=[{'key':'full-right','name':'右腿總成 · ID 10–14','items':[k for g in groups if g['key'] in right and g['key']!='trunkbottom' for k in g['items']],
           'color':gold,'offset':[0,-140,-35],'center':[0,-80,-100],'detail':'右腿五顆 ID 已配置。此模式整條腿一起移開；切換右腿模式可拆看內部零件。'}]
    full.extend([g for g in groups if g['key'] in ['trunkbottom','leftleg','neck','head','torso']])
    offsets={'full-right':[0,-240,-60],'trunkbottom':[0,0,0],'leftleg':[0,280,-60],'neck':[0,0,100],'head':[0,0,220],'torso':[-230,0,90]}
    full=[{**g,'offset':offsets[g['key']]} for g in full]
    all_keys=[k for g in full for k in g['items']]
    assert len(all_keys)==len(set(all_keys))==len(visuals), 'Full scene must include every visual once'
    # Left leg: same order as the right scene so both can be worked through part by part.
    # Only the side-specific CAD files differ; exploded offsets mirror in y (right is -y, left is +y).
    lbearing=max(select('roll_bearing.stl','trunk_assembly'),key=lambda v:v['center'][1])
    lthigh=[v for v in visuals if v['link']=='knee_and_ankle_assembly' and not v['motor'] and 'cache' not in v['mesh']]
    lshin=[v for v in visuals if v['link']=='knee_and_ankle_assembly_2' and not v['motor']]
    left=[
      make('id20','ID 20 · 左髖 yaw',select(id=20),dark,[0,0,100],'已驗收、設 ID、裝舵盤。與 ID 10 同款同方向：向下的主動舵盤接 roll_motor_top，上端圓盤是背面支承盤。'),
      make('lrolltop','roll_motor_top',select('roll_motor_top.stl','hip_roll_assembly'),gold,[0,0,60],'與右側同一個列印件，不分左右。四個固定孔對準 ID 20 下方主動舵盤，由底部往上鎖；此件不壓熱熔嵌件。'),
      make('id21','ID 21 · 左髖 roll',select(id=21),dark,[0,0,10],'側向輸出接 left_roll_to_pitch，輸出方向與右腿相反。舵機外殼由 roll_motor_top 與 roll_motor_bottom 共同支承。'),
      make('lrollbottom','roll_motor_bottom',select('roll_motor_bottom.stl','hip_roll_assembly'),gold,[0,0,-35],'與右側同一個列印件。底部約 Ø20 凸軸進入 6804ZZ 內圈；不是把軸承外圈壓進這個零件。'),
      make('lbearing','6804ZZ · 左髖軸承',[lbearing],steel,[0,0,-80],'左髖用的另一顆軸承，與右髖同規格。內圈接 roll_motor_bottom 凸軸，外圈固定在 trunk_bottom 的座孔。'),
      make('trunkbottom','trunk_bottom',select('trunk_bottom.stl','trunk_assembly'),teal,[0,0,-185],'與右腿共用同一個軀幹底座；兩側髖軸承都固定在這一件上。左腿接上之前，右髖那側應已定位。'),
      make('lbridge','left_roll_to_pitch',select('left_roll_to_pitch.stl'),gold,[35,75,-20],'左側專用連接件，與 right_roll_to_pitch 不對稱也不可互換。連接 ID 21 輸出與 ID 22 機身。'),
      make('id22','ID 22 · 左髖 pitch',select(id=22),dark,[35,95,-20],'大腿上端。裝配方向採官方 CAD 零位，與右腿 ID 12 鏡像；實機仍需後續校正。'),
      make('lthigh','左大腿 · 薄板 ×2＋spacer',lthigh,gold,[0,100,-65],'薄板左右腿共用同兩種列印件，每腿各一片。每件 spacer 用四顆嵌件；先辨識孔位，再裝兩端舵機。'),
      make('lcache','left_cache · 左腿外側護蓋',select('left_cache.stl','knee_and_ankle_assembly'),teal,[90,120,-65],'這是左大腿外側護蓋，不是軀幹外殼。確認 ID 22、ID 23 與線束位置後再封上。'),
      make('id23','ID 23 · 左膝',select(id=23),dark,[0,135,-95],'上下連接大腿與小腿。先確認相鄰結構與線路不干涉，不以模擬角度當作真實機械止點。'),
      make('lshin','左小腿 · 薄板 ×2＋spacer',lshin,gold,[0,100,-125],'裝薄板前先插踝舵機線，讓線穿過薄板開孔。左腿的走線方向與右腿相反，不可照抄右腿的穿孔面。'),
      make('id24','ID 24 · 左踝',select(id=24),dark,[0,135,-160],'安裝在腳部，驅動板所在的一面朝 foot_top。以官方組裝圖辨認，不能只憑線朝哪裡判斷。'),
    ]+[make(key,name,select(mesh,'foot_assembly'),teal if key=='lfoottpu' else gold,off,detail) for key,mesh,name,off,detail in [
      ('lfoottop','foot_top.stl','foot_top · 上蓋',[0,100,-170],'腳部四件左右腿共用同款列印件。三顆嵌件；孔深先量再選嵌件長度。'),
      ('lfootside','foot_side.stl','foot_side · 側板',[65,120,-190],'與踝舵機、上蓋合裝；鎖塑膠的螺絲不使用螺紋膠。'),
      ('lfootpla','foot_bottom_pla.stl','foot_bottom_pla · 硬底',[0,100,-220],'兩顆嵌件；用兩顆 M3×6 接 TPU 腳底。'),
      ('lfoottpu','foot_bottom_tpu.stl','foot_bottom_tpu · 軟底',[0,100,-255],'TPU 40% 填充，與 PLA 硬底配合。腳底開關另依官方圖壓入。')]]
    # Torso: every trunk visual exactly once; actual CAD transforms preserved.
    body=[]
    specs=[
      ('trunk_bottom.stl','軀幹底座 · trunk_bottom',[0,0,-140]),
      ('trunk_top.stl','軀幹上座 · trunk_top',[0,0,160]),
      ('body_front.stl','前殼 · body_front',[150,0,0]),
      ('body_back.stl','後殼 · body_back',[-150,0,0]),
      ('body_middle_bottom.stl','中段下殼 · body_middle_bottom',[0,-180,-40]),
      ('body_middle_top.stl','中段上殼 · body_middle_top',[0,300,120]),
      ('battery_pack_lid.stl','電池蓋 · battery_pack_lid',[-70,-160,-100])]
    body_details={
      'trunk_bottom.stl':'先壓入左右髖軸承與上游標出的 M3 嵌件，底面另有 4 顆 M3 嵌件供外殼固定。再用 2 顆 M3×10 與 trunk_top 結合。',
      'trunk_top.stl':'與 trunk_bottom 用 2 顆 M3×10 鎖合。裝殼前完成 ID 10、20、30 與主線束出口，避免後續拆開。',
      'body_front.stl':'最後階段才封前殼；先完成電池座、電源、舵機板與頸部線束。鎖入中段的 M3 嵌件，實際長度依孔深量測。',
      'body_back.stl':'後殼是維修入口之一；先確認開關、充電與電池蓋可操作。上游未列螺絲長度，量測咬合深度後選用。',
      'body_middle_bottom.stl':'先固定到 trunk 結構，再把將固定電池座與 body_front 的孔全部壓入 M3 嵌件。接線與電池座試配後再鎖。',
      'body_middle_top.stl':'在頭部機構完全裝死前先套入，避免之後拆頭。壓入固定電池座與 body_front 所需 M3 嵌件。',
      'battery_pack_lid.stl':'電池與保護板完成絕緣、固定及拉力釋放後才裝。確保拆蓋不會拉扯電源線；上電前另做極性與短路檢查。'}
    for i,(mesh,name,offset) in enumerate(specs):
        body.append(make('body-'+str(i),name,select(mesh,'trunk_assembly'),gold if i>1 else teal,offset,body_details[mesh]))
    body.append(make('body-bearing','左右髖軸承 ×2',select('roll_bearing.stl','trunk_assembly'),steel,[0,0,-70],'外圈在 trunk_bottom，內圈接髖座凸軸。'))
    for mid,name,offset in [(10,'右髖 yaw',[0,-55,60]),(20,'左髖 yaw',[0,55,60]),(30,'頸部 pitch',[0,0,115])]:
        group=make(f'body-servo-{mid}',f'ID {mid} · {name}',[v for v in visuals if v['link']=='trunk_assembly' and v.get('id')==mid],dark,offset,f'ID {mid}：{name}。左右以機器人自身為準；包含 CAD 舵盤。此圖為設計零位，不是歸零指令。')
        group['servoId']=mid
        body.append(group)
    body.append(make('body-battery','電池與電池座 · CAD 參考',[v for v in visuals if v['link']=='trunk_assembly' and v['mesh'] in ['cell.stl','holder.stl']],teal,[-80,0,-20],'電子件只作位置參考，請以實際電池座與接線配置試配。'))
    body_used={k for g in body for k in g['items']}
    body.append(make('body-electronics','板件、開關與充電模組',[v for v in visuals if v['link']=='trunk_assembly' and v['key'] not in body_used],steel,[220,120,70],'上游 CAD 電子配置，不能當成實際接腳或此次 BMS／充電器接線圖。'))
    body_keys=[k for g in body for k in g['items']]
    assert len(body_keys)==len(set(body_keys))==len(select(link='trunk_assembly'))
    # Neck: include both interfaces so the builder can see how the five printed
    # neck parts bridge trunk_top to the head, together with all four servos.
    neck_scene=[]
    neck_specs=[
      ('neck-trunk','身體接口 · trunk_top',select('trunk_top.stl','trunk_assembly'),teal,[0,0,-170],'頸部從 trunk_top 上方開始。先確認 ID 30 線材已接好並留出活動餘量，再鎖上頸部。'),
      ('neck-id30','ID 30 · 頸 pitch',select(id=30),dark,[0,0,-105],'位於身體上方的頸部 pitch 舵機。主動舵盤接頸部薄板總成；此圖是 CAD 零位，不是舵機歸零命令。'),
      ('neck-left','neck_left_sheet',select('neck_left_sheet.stl','neck_pitch_assembly'),gold,[-100,0,-45],'左頸薄板；左右以機器人自身為準。它與 right_sheet 不同，不可互換。'),
      ('neck-right','neck_right_sheet',select('neck_right_sheet.stl','neck_pitch_assembly'),gold,[100,0,-45],'右頸薄板；孔位與方向需和左片對照後再鎖。封板前先接 ID 31。'),
      ('neck-id31','ID 31 · 頭 pitch',select(id=31),dark,[0,0,20],'夾在左右頸薄板之間。先插線，再確認舵盤與薄板孔位，避免薄板合上後無法接插頭。'),
      ('neck-pitch-yaw','head_pitch_to_yaw',select('head_pitch_to_yaw.stl','head_pitch_to_yaw'),gold,[0,0,85],'連接 ID 31 pitch 輸出與 ID 32 yaw 舵機，是五件頸部列印件之一。'),
      ('neck-id32','ID 32 · 頭 yaw',select(id=32),dark,[0,0,145],'控制頭部左右轉。安裝前確認線束穿過中央通道，轉到兩側時都不能拉緊。'),
      ('neck-yaw-roll','head_yaw_to_roll',select('head_yaw_to_roll.stl','neck_yaw_assembly'),gold,[0,0,210],'連接 ID 32 yaw 與 ID 33 roll，是五件頸部列印件之一。'),
      ('neck-id33','ID 33 · 頭 roll',select(id=33),dark,[0,0,275],'控制頭部側傾；輸出端接 head_roll_mount，另一側由軸承支承。'),
      ('neck-bearing','頭部 roll 支承軸承',select('roll_bearing.stl','head_assembly'),steel,[0,0,335],'軸承外圈固定在頭部結構，內圈支承 roll 軸。不要用敲擊方式壓過舵機輸出軸。'),
      ('neck-roll-mount','head_roll_mount',select('head_roll_mount.stl','head_assembly'),gold,[0,0,395],'第五件頸部列印件；承接 ID 33 與頭部總成。先確認軸承、舵盤及螺絲都能自由對位。')]
    for key,name,items,color,offset,detail in neck_specs:
        group=make(key,name,items,color,offset,detail)
        if key.startswith('neck-id'): group['servoId']=int(key.removeprefix('neck-id'))
        neck_scene.append(group)
    neck_keys=[k for g in neck_scene for k in g['items']]
    assert len(neck_keys)==len(set(neck_keys)), 'Neck scene must not repeat visuals'
    head_scene=[
      make('head-shell','head · 頭殼',select('head.stl','head_assembly'),gold,[-120,0,80],'先依上游標示壓入頭殼所需 M3 嵌件。殼體最後封閉；先完成軸承、耳朵舵機、Pi、燈與喇叭走線。'),
      make('head-bottom','head_bot_sheet · 頭部底板',select('head_bot_sheet.stl','head_assembly'),gold,[0,0,-150],'在頸部機構完全鎖死前套入；上游特別提醒此件若漏裝，之後可能必須拆頭部機構。'),
      make('head-roll','head_roll_mount',select('head_roll_mount.stl','head_assembly'),gold,[70,0,-80],'接 ID 33 主動端並承接頭部。先和對側 roll 軸承自然對位，再逐步鎖緊。'),
      make('head-bearing','roll 軸承',select('roll_bearing.stl','head_assembly'),steel,[-70,0,-80],'壓入頭殼的對側支承孔；只對軸承外圈均勻施力，不能經舵機輸出軸敲入。'),
      make('head-id33','ID 33 · 頭 roll',select(id=33),dark,[0,0,-20],'頭部側傾舵機。金屬對金屬螺絲使用少量藍色 243；鎖入塑膠的螺絲不可使用螺紋膠。'),
      make('head-pi','Raspberry Pi Zero 2 W · CAD 參考',select('raspberrypizerow.stl','head_assembly'),steel,[0,130,30],'固定前先接相機排線及會被頭殼遮住的線。CAD 只表示板位，支柱與接頭方向依實際板型核對。'),
      make('head-board','舵機驅動板 · CAD 參考',select('board.stl','head_assembly'),steel,[0,-140,30],'上游裝配指南尚未提供照片；先確認舵機匯流排、電源與 Pi 通訊線，再封殼。接腳依實際板型。'),
      make('head-ears','左右耳舵機 ×2',select('sg90.stl','head_assembly'),dark,[-40,0,70],'左右耳舵機先裝入頭殼並試走線；避免輸出臂與天線座在全行程碰撞。'),
      make('head-antennas','左右天線座',select('left_antenna_holder.stl','left_antenna_holder')+select('right_antenna_holder.stl','right_antenna_holder'),gold,[-80,0,145],'左右件不同，不可互換。對應耳舵機；先確認零位與活動空間再裝天線。'),
      make('head-eyes','left_eye／right_eye',select('left_eye.stl','head_accessories')+select('right_eye.stl','head_accessories'),teal,[140,0,45],'兩眼為不同零件，依機器人自身左右裝入前方孔位。LED 線先接；左眼 GPIO 23、右眼 GPIO 24，共陰極接 GND。'),
      make('head-light','投射燈 · module＋reflector＋bulb',select('flash_light_module.stl','head_accessories')+select('flash_reflector_interface.stl','head_accessories')+select('bulb.stl','head_accessories'),teal,[120,110,95],'三件依共同 CAD 座標對應前方投射燈接口。GPIO 25 控制燈；光學件與實際燈板先試配，封殼前完成絕緣與拉力釋放。'),
      make('head-speaker','喇叭 · stand＋interface',select('speaker_stand.stl','head_accessories')+select('speaker_interface.stl','head_accessories'),teal,[80,-125,100],'兩件形成喇叭與 MAX98357A 安裝接口。先接 LRC GPIO19、BCLK GPIO18、DIN GPIO21、5V 與 GND，再固定並避免線碰 roll 機構。')]
    head_keys=[k for g in head_scene for k in g['items']]
    expected_head=[v['key'] for v in visuals if v['link'] in head_links and v['mesh']!='antenna.stl']
    assert set(head_keys)==set(expected_head), 'Head scene must cover every printable/internal head item once'
    def serial(v):
        mat=v['matrix'].copy();mat[:3,:]*=1000
        return {'key':v['key'],'mesh':v['mesh'],'matrix':mat.T.reshape(-1).round(7).tolist(),'id':v.get('id')}
    data={'version':'2026-09-07','source':'Open_Duck_Mini/mini_bdx/robots/open_duck_mini_v2/robot.urdf',
          'sourceSha256':hashlib.sha256((SOURCE/'robot.urdf').read_bytes()).hexdigest(),
          'geometries':geom,'visuals':[serial(v) for v in visuals],
          'scenes':{'hip':{'title':'右髖座','groups':groups[:6]},'right':{'title':'右腿','groups':[g for g in groups if g['key'] in right]},
                    'body':{'title':'身體','groups':body},'neck':{'title':'頸部','groups':neck_scene},'head':{'title':'頭部','groups':head_scene},
                    'left':{'title':'左腿','groups':left},'full':{'title':'全機總成','groups':full}}}
    (OUT/'assembly-data.json').write_text(json.dumps(data,separators=(',',':'),ensure_ascii=False))
    print('Wrote assembly-data.json',len(geom),'meshes',len(visuals),'visual instances')
    return data,visuals,meshes

if __name__=='__main__': build()
