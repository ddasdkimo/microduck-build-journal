"""Right shin three-part union preview; millimetres, no servo geometry."""
from pathlib import Path
import xml.etree.ElementTree as ET
import json
import numpy as np
import trimesh
from build_assembly_data import SOURCE, ROOT, tf
OUT=ROOT/'designs/right-shin-unibody-v1'
OUT.mkdir(parents=True,exist_ok=True)
link=ET.parse(SOURCE/'robot.urdf').getroot().find("link[@name='knee_and_ankle_assembly_4']")
parts=[];names=[]
for visual in link.findall('visual'):
    name=visual.find('geometry/mesh').get('filename').split('/')[-1]
    if 'sheet' not in name and name!='leg_spacer.stl':continue
    mesh=trimesh.load(SOURCE/name,force='mesh')
    mesh.apply_transform(tf(visual.find('origin')));mesh.apply_scale(1000)
    if name=='leg_spacer.stl':
        # Extend the spacer by 0.25 mm at each end to bridge CAD assembly clearance.
        zmid=mesh.bounds[:,2].mean();height=mesh.extents[2]
        mesh.vertices[:,2]=zmid+(mesh.vertices[:,2]-zmid)*(height+0.5)/height
    parts.append(mesh);names.append(name)
combined=trimesh.boolean.union(parts,engine='manifold')
assert combined.is_watertight and len(combined.split())==1, 'Union must be a single closed solid'
print('Union:',combined.is_watertight,'components',len(combined.split()),'volume',combined.volume,flush=True)
# Center XY and set lowest Z on the build plane; this is preview orientation only.
shift=-(combined.bounds[0]+combined.bounds[1])/2;shift[2]=-combined.bounds[0,2]
combined.apply_translation(shift)
combined.export(OUT/'right-shin-unibody-preview.stl')
for p in parts:p.apply_translation(shift)
report={'units':'mm','source_link':'knee_and_ankle_assembly_4','parts':names,'extents_mm':combined.extents.tolist(),'watertight':bool(combined.is_watertight),'connected_components':len(combined.split()),'volume_mm3':float(combined.volume),'preview_only':True,'spacer_end_extension_mm':0.25}
(OUT/'geometry-check.json').write_text(json.dumps(report,indent=2))
# Render actual union mesh from two directions.
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.collections import PolyCollection
fig,axes=plt.subplots(1,2,figsize=(13,7),facecolor='#f7f6f1')
for ax,view in zip(axes,[np.array([1.,-1.8,1.6]),np.array([-1.4,.9,1.3])]):
 view/=np.linalg.norm(view);right=np.cross([0,0,1],view);right/=np.linalg.norm(right);up=np.cross(view,right)
 tri=(combined.vertices@np.stack([right,up,view]).T)[combined.faces]
 normal=np.cross(tri[:,1]-tri[:,0],tri[:,2]-tri[:,0]);normal/=np.maximum(np.linalg.norm(normal,axis=1)[:,None],1e-12)
 shade=.45+.55*np.abs(normal@np.array([-.3,.4,.866]));colors=shade[:,None]*np.array([.18,.52,.49])
 order=np.argsort(tri[:,:,2].mean(1));ax.add_collection(PolyCollection(tri[order,:,:2],facecolors=colors[order],edgecolors='none'))
 ax.autoscale_view();ax.set_aspect('equal');ax.axis('off');ax.set_facecolor('#f7f6f1')
fig.suptitle('RIGHT SHIN / THREE-PART UNION',fontsize=21,color='#173e44',y=.94)
fig.text(.5,.05,'CAD union preview | mm | Assembly access and print orientation not yet validated',ha='center',fontsize=11,color='#53666a')
fig.savefig(OUT/'right-shin-unibody-preview.png',dpi=170,facecolor=fig.get_facecolor());plt.close(fig)
print(json.dumps(report),flush=True)
